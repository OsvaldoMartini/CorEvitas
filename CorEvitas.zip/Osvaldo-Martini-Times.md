# Steps taken  
1) Open (Intellij) and Read the Project specifications at 13/07/23 17:30
2) Github pages deploy at 13/07/23 17:35
3) Patterns for Repositories/Services/Controller/H2 Database at 13/07/23 18:54
4) Stopped at 13/07/23 19:09
> I stopped here to understand the REAL meaning of using console IN_OUT 
> Pushing all into the Github

## Tools Libraries utilized 
 - Spring Framework 3.0.5
 - Spotless
 - Lombok

## Postman Collection initial tests 
### Add Product to Troller
![1](Postman/Add-Product-to-Troller.png)
### Get Product by Id
![1](Postman/Get-Product-by-Id.png)
### Reduce Product Qty by Id
![1](Postman/Reduce-Product-by-Id.png)

