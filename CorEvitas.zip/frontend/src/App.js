import React from "react";
import "./App.css";
import Troller from "../src/Components/Troller";

function App() {
  return <Troller />;
}

export default App;
