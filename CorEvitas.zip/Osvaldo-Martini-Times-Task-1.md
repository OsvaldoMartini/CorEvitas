# Steps taken  
1) Using TDD as first approach to solve the implementations at 10:30 (UK time) 20/07/2023
2) Defining the Enum "ProductsTypesEnum" Types to produce data for testing
3) Jumping to the FrontEnd
4) Finished at 13:20 (UK time) 20/07/2023
5) Done

### FrontEnd result
![1](frontend.png)